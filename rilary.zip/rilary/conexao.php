<?php

$servidor ="localhost";
$usurario = "root";
$senha= "";
$banco = "agenda_31";


$conexao = mysqli_connect($servidor,$usurario,$senha,$banco);

if (!$conexao){
    die ('Falha na conexão.'.mysqli_connect_error());
}

?>
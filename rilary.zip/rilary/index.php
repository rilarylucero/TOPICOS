<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda - Turma 31</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="index.css">
</head>
<body style="background-color:#F4F3E6;">

<section class="h-100 gradient-form">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-xl-10">
                
                <div class="card rounded-3 text-black">
                    <div class="row g-0">
                        <div class="col-lg-6">
                            <div class="card-body p-md-5 mx-md-4">
                                <div class="text-center">
                                    <h4 class="mt-1 mb-5 pb-1">Agenda Turma 31</h4>
                                </div>

                                <form action="salvar.php" method="POST">
                                    <p class="text-center fw-bold">CADASTRO DE CONTATOS</p>
                                    <div class="form-outline mb-4">
                                        <label class="form-label">Nome</label>
                                        <input type="text" name="nome" class="form-control" placeholder="Digite o nome" required />
                                    </div>
                                    <div class="form-outline mb-4">
                                        <label class="form-label">Endereço</label>
                                        <input type="text" name="endereco" class="form-control" placeholder="Rua, número" />
                                    </div>
                                    <div class="form-outline mb-4">
                                        <label class="form-label">Telefone</label>
                                        <input type="text" name="fone" class="form-control" placeholder="(00) 9 00000000" />
                                    </div>
                                    <div class="text-center pt-1 mb-5 pb-1">
                                        <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3 border-0 w-100" type="submit">
                                            Cadastrar Contato
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                            <div class="text-white px-3 py-4 p-md-5 mx-md-4">
                                <h4 class="mb-4">Gerenciamento de Contatos</h4>
                                <p class="small mb-0">Utilize o formulário ao lado para organizar sua lista de contatos da turma.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-container shadow-sm">
                    <h2 class="h4 mb-4 text-center">Lista de Contatos</h2>
                    <div class="table-responsive">
                        <?php 
                        include('conexao.php');
                        $sql = "SELECT * FROM contatos ORDER BY nome ASC";
                        $resultado = mysqli_query($conexao, $sql);

                        if (mysqli_num_rows($resultado) > 0) {
                            echo "<table class='table table-hover table-striped'>";
                            echo "<thead class='custom-thead'>
                                    <tr>
                                        <th>Nome</th>
                                        <th>Endereço</th> 
                                        <th>Telefone</th> 
                                        <th colspan='2' class='text-center'>Ações</th> 
                                    </tr>
                                  </thead><tbody>";

                            while ($linha = mysqli_fetch_assoc($resultado)) {
    echo "<tr>
            <td>".$linha['nome']."</td>
            <td>".$linha['endereco']."</td>
            <td>".$linha['telefone']."</td>
            <td class='text-center'>
                <a href='editar.php?id=".$linha['id']."' class='btn btn-sm btn-outline-primary'>Editar</a>
            </td>
            <td class='text-center'>
                <a href='excluir.php?id=".$linha['id']."' 
                   class='btn btn-sm btn-outline-danger' 
                   onclick=\"return confirm('Tem certeza que deseja excluir este contato?')\">
                   Excluir
                </a>
            </td>
          </tr>";    

                            }
                            echo "</tbody></table>";
                        } else {
                            echo "<div class='alert alert-warning text-center'>Nenhum contato encontrado!</div>";
                        }
                        ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>

</body>
</html>
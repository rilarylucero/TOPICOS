<?php 
include ('conexao.php');

$nome = $_POST['nome']; 
$endereco = $_POST['endereco']; 
$fone = $_POST['fone'];

$sql = "INSERT INTO contatos (nome, endereco, telefone) VALUES ('$nome', '$endereco', '$fone')";
$sucesso = mysqli_query($conexao, $sql);
?>
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <title>Resultado</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="salvar.css">
        </head>
        <body class="tela-centralizada">
            <div class="card card-res">
                <div class="card-body p-5 text-center">
                    <?php if($sucesso): ?>
                        <h2 style="color: #FC703C;">Sucesso!</h2>
                        <p>O contato  <strong><?php echo htmlspecialchars($nome); ?></strong> foi salvo.</p>
                    <?php else: ?>
                        <h2 class="text-danger">Erro!</h2>
                        <p><?php echo mysqli_error($conexao); ?></p>
                    <?php endif; ?>
                    <a href="index.php" class="btn btn-voltar">Voltar</a>
                </div>
            </div>
        </body>
</html>
<?php 
include ('conexao.php');

if (isset($_GET['id'])){
    $id = intval($_GET['id']);
    $sql = "DELETE FROM contatos WHERE id = $id";
    $sucesso = mysqli_query($conexao, $sql);
} else {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Excluir Contato</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="excluir.css">
    <meta http-equiv="refresh" content="3;url=index.php">
</head>
<body class="body-excluir">
    <div class="card-exclusao shadow">
        <div class="header-excluir">
            <?php echo $sucesso ? "Sucesso!" : "Erro!"; ?>
        </div>
        <div class="card-body p-4 text-center">
            <?php if($sucesso): ?>
                <p>O contato foi removido com sucesso.</p>
                <p class="small text-muted">Você será redirecionado em instantes...</p>
            <?php else: ?>
                <p>Erro ao excluir: <?php echo mysqli_error($conexao); ?></p>
            <?php endif; ?>
            <a href="index.php" class="btn-voltar-excluir mt-3">Voltar Agora</a>
        </div>
    </div>
</body>
</html>
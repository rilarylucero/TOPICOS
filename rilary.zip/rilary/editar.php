<?php
include('conexao.php');

// mds professor, eu manjei muito nesses aqui

$id = $_GET['id'];

$sql = "SELECT * FROM contatos WHERE id = $id";
$resultado = mysqli_query($conexao, $sql);

if (mysqli_num_rows($resultado) == 1) {
    $contato = mysqli_fetch_assoc($resultado);
} else {
    echo "Contato não encontrado!";
    exit;
}

if (isset($_POST['atualizar'])) {
    $novo_nome = $_POST['nome'];
    $novo_endereco = $_POST['endereco'];
    $novo_fone = $_POST['fone'];

    $sql2 = "UPDATE contatos SET nome='$novo_nome', endereco='$novo_endereco', telefone='$novo_fone' WHERE id=$id";

    if (mysqli_query($conexao, $sql2)) {
        echo "
                <!DOCTYPE html>
                <html lang='pt-br'>
                <head>
                <meta charset='UTF-8'>
                <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
                <link rel='stylesheet' href='editar.css'>
                </head>
                <body class='body-editar'>

                <div class='container d-flex justify-content-center align-items-center' style='height:100vh;'>
                <div class='card text-center card-res-edit shadow'>

                <div class='card-header text-white' style='background: linear-gradient(to right, #5D0703, #FC703C); font-weight:bold;'>
                Sucesso!
                </div>

                <div class='card-body'>
                <h5 class='card-title' style='color:#5D0703;'></h5>
                <p class='card-text'>O contato de <strong>$novo_nome</strong> foi atualizado.</p>

                <a href='index.php' class='btn btn-gradiente'>Voltar</a>

                </div>
                </div>
                </div>

                </body>
                </html>";

        exit;
    } else {
        echo "Erro ao atualizar: " . mysqli_error($conexao);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Contato - Turma 31</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="editar.css">
</head>
<body class="body-editar">

<div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    <div class="row justify-content-center w-100">
        <div class="col-md-5">
            <div class="card card-edicao shadow-lg" style="border-radius: 20px; border: none;">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Editar Contato</h3>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nome:</label>
                            <input type="text" name="nome" class="form-control" value="<?php echo $contato['nome']; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Endereço:</label>
                            <input type="text" name="endereco" class="form-control" value="<?php echo $contato['endereco']; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefone:</label>
                            <input type="text" name="fone" class="form-control" value="<?php echo $contato['telefone']; ?>">
                        </div>
                        
                        <input type="submit" name="atualizar" value="Atualizar Contato" class="btn btn-gradiente w-100">
                        
                        <div class="text-center mt-3">
                           <a href="index.php" class="link-cancelar" style="color: #5D0703; text-decoration: none;">Cancelar e Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>